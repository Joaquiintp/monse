/**
 * acta controller
 */
import { factories } from '@strapi/strapi';
export default factories.createCoreController('api::acta.acta');
