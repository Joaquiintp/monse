/**
 * acta service
 */
import { factories } from '@strapi/strapi';
export default factories.createCoreService('api::acta.acta');
