/**
 * monsexmundo router
 */
import { factories } from '@strapi/strapi';
export default factories.createCoreRouter('api::monsexmundo.monsexmundo');
