import { mergeConfig } from 'vite';

export default (config) => {
  return mergeConfig(config, {
    server: {
      allowedHosts: [
        'localhost',
        '127.0.0.1',
        '168.231.99.125',
        'strapi.monserratenses.org.ar',
        'monserratenses.org.ar',
      ],
      host: '0.0.0.0',
      port: 1337,
    },
  });
};
